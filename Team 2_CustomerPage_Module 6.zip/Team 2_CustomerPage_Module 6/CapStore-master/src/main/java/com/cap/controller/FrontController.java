package com.cap.controller;

public class FrontController {

}
