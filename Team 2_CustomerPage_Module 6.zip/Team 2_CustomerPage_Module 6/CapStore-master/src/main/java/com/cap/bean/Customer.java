package com.cap.bean;


public class Customer {
	
	private String name;
	private String email;
	private String password;
	private String birthday;
	private String gender;
	private String phone;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getphone() {
		return phone;
	}
	public void setphone(String phone) {
		this.phone = phone;
	}
	
	private Customer() {
		
	}
	public Customer(String name, String email, String password, String birthday, String gender, String phone) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.birthday = birthday;
		this.gender = gender;
		this.phone = phone;
	}

	
}
