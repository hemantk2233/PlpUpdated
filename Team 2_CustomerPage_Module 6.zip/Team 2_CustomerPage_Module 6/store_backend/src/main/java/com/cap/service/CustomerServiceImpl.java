package com.cap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.bean.ChangeProfile;
import com.cap.repo.ICustomerRepo;

@Service
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	private ICustomerRepo repo;

	@Override
	public void updateProfile(String name, String email, String birthmonth, String birthdate, String birthyear,
			String gender, String phone) {
		ChangeProfile c= new ChangeProfile();
		repo.save(c);
	}

	
	}


