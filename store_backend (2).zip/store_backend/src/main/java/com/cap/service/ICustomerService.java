package com.cap.service;


public interface ICustomerService {
	
	public void updateProfile(String name, String email, String birthmonth, String birthdate, String birthyear, String gender, String phone);

}
