package com.cap.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cap.bean.Customer;

@Repository
public interface ICustomerRepo extends CrudRepository<Customer, String>{

}
